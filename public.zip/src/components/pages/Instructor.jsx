export default function Instructor(){

return(

<>
  {/* START SECTION TOP */}
  <section className="section-top">
    <div className="container">
      <div className="col-lg-10 offset-lg-1 text-center">
        <div
          className="section-top-title wow fadeInRight"
          data-wow-duration="1s"
          data-wow-delay="0.3s"
          data-wow-offset={0}
        >
          <h1>Our instructor</h1>
          <ul>
            <li>
              <a href="index.html">Home</a>
            </li>
            <li> / instructor</li>
          </ul>
        </div>
        {/* //.HERO-TEXT */}
      </div>
      {/*- END COL */}
    </div>
    {/*- END CONTAINER */}
  </section>
  {/* END SECTION TOP */}
  {/* START TEAM */}
  <section className="team_area section-padding">
    <div className="container">
      <div className="section-title text-center">
        <h2>Meet our Instructors</h2>
        <p>
          We offer a brand new approach to the most basic learning paradigms.
          Choose from a wide range of learning options and gain new skills! Our
          school is know.
        </p>
      </div>
      <div className="row">
        <div
          className="col-lg-3 col-sm-6 col-xs-12 wow fadeInUp"
          data-wow-duration="1s"
          data-wow-delay="0.1s"
          data-wow-offset={0}
        >
          <div className="our-team">
            <div className="team-content">
              <a href="#">
                <img src="assets/img/team/team1.jpg" alt="" />
              </a>
              <ul className="social-links">
                <li>
                  <a href="#">
                    <i className="fa-solid fa-x" />
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa-brands fa-facebook-f" />
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa-brands fa-linkedin-in" />
                  </a>
                </li>
              </ul>
            </div>
            <div className="team-prof">
              <h3>Bilkis Vabi</h3>
              <span>Web designer</span>
            </div>
            <div className="sth_det2">
              <span className="ti-file">
                {" "}
                <u>04 Course</u>
              </span>
              <span className="ti-user">
                {" "}
                <u>27 Student</u>
              </span>
            </div>
          </div>
        </div>
        {/*- END COL */}
        <div
          className="col-lg-3 col-sm-6 col-xs-12 wow fadeInUp"
          data-wow-duration="1s"
          data-wow-delay="0.1s"
          data-wow-offset={0}
        >
          <div className="our-team">
            <div className="team-content">
              <a href="#">
                <img src="assets/img/team/team2.jpg" alt="" />
              </a>
              <ul className="social-links">
                <li>
                  <a href="#">
                    <i className="fa-solid fa-x" />
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa-brands fa-facebook-f" />
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa-brands fa-linkedin-in" />
                  </a>
                </li>
              </ul>
            </div>
            <div className="team-prof">
              <h3>Mood Wasim</h3>
              <span>TemplateMonster company</span>
            </div>
            <div className="sth_det2">
              <span className="ti-file">
                {" "}
                <u>06 Course</u>
              </span>
              <span className="ti-user">
                {" "}
                <u>41 Student</u>
              </span>
            </div>
          </div>
        </div>
        {/*- END COL */}
        <div
          className="col-lg-3 col-sm-6 col-xs-12 wow fadeInUp"
          data-wow-duration="1s"
          data-wow-delay="0.1s"
          data-wow-offset={0}
        >
          <div className="our-team">
            <div className="team-content">
              <a href="#">
                <img src="assets/img/team/team3.jpg" alt="" />
              </a>
              <ul className="social-links">
                <li>
                  <a href="#">
                    <i className="fa-solid fa-x" />
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa-brands fa-facebook-f" />
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa-brands fa-linkedin-in" />
                  </a>
                </li>
              </ul>
            </div>
            <div className="team-prof">
              <h3>Shyinn tim</h3>
              <span>Codecanyou</span>
            </div>
            <div className="sth_det2">
              <span className="ti-file">
                {" "}
                <u>13 Course</u>
              </span>
              <span className="ti-user">
                {" "}
                <u>31 Student</u>
              </span>
            </div>
          </div>
        </div>
        {/*- END COL */}
        <div
          className="col-lg-3 col-sm-6 col-xs-12 wow fadeInUp"
          data-wow-duration="1s"
          data-wow-delay="0.1s"
          data-wow-offset={0}
        >
          <div className="our-team">
            <div className="team-content">
              <a href="#">
                <img src="assets/img/team/team4.jpg" alt="" />
              </a>
              <ul className="social-links">
                <li>
                  <a href="#">
                    <i className="fa-solid fa-x" />
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa-brands fa-facebook-f" />
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa-brands fa-linkedin-in" />
                  </a>
                </li>
              </ul>
            </div>
            <div className="team-prof">
              <h3>Shorif shorifa</h3>
              <span>Tsc chottor</span>
            </div>
            <div className="sth_det2">
              <span className="ti-file">
                {" "}
                <u>07 Course</u>
              </span>
              <span className="ti-user">
                {" "}
                <u>24 Student</u>
              </span>
            </div>
          </div>
        </div>
        {/*- END COL */}
      </div>
      {/*- END ROW */}
    </div>
    {/*- END CONTAINER */}
  </section>
  {/* END TEAM */}
</>






)






}




