import {createUserWithEmailAndPassword, signOut} from 'firebase/auth'
import  { auth, db } from "../firebase/firebase"
import UseModel from '../models/UseModel'
import { doc, setDoc } from 'firebase/firestore'
 class Userservice{

async register(data){
    const userdata= await createUserWithEmailAndPassword(auth, data.email, data.password)
    const user= userdata.user
    let newUser= new UseModel()
    newUser.id=user.uid
    newUser.email= data.email
    newUser.name= data.name
    newUser.userType= "student"

    const setDocData= await setDoc(doc(db,"user",user.uid),{...newUser})
    await signOut(auth)
    return setDocData
}

}

export default new Userservice()