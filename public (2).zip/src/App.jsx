
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Home from "./components/home/Home"
import About from "./components/about/About"
import Course from './components/course/Course'
import Coursedetail from "./components/course/Coursedetail"
import Instructor from './components/pages/Instructor'
import Instructordetail from './components/pages/Instructordetail'
import Pricingplan from './components/pages/Pricingplan'
import StudentLayout from './components/students/layout/StudentLayout'
import Contact from './components/contact/Contact'
import Signup from "./components/pages/Signup";
function App() {


  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<StudentLayout />}>
            <Route path='/' element={<Home />}></Route>
            <Route path='/about' element={<About />}></Route>
            <Route path='/course' element={<Course />}></Route>
            <Route path='/coursedetail' element={<Coursedetail />}></Route>
            <Route path="/instructor" element={<Instructor />}></Route>
            <Route path="/instructordetail" element={<Instructordetail />}></Route>
            <Route path="/pricingplan" element={<Pricingplan />}></Route>
            <Route path="/contact" element={<Contact />}></Route>
            <Route path="/signup" element={<Signup />} />

          </Route>

        </Routes>

      </BrowserRouter>
    </>
  )
}

export default App
