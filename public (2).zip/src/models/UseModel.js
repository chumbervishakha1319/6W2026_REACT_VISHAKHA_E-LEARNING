export default class UserModel{
    
    name= ""
    email= ""
    phone=""
    profileImage=""
    qualification= ""
    userType= "student"
    status="active"
    createdAt= Date.now()
    updatedAt=Date.now()

}
